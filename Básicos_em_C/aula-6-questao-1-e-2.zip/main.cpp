#include <stdio.h>

int main()
{ 
    
    char nome [100];
    int idade;
    printf("Qual seu nome?\n");
    
   scanf("%s",&nome);
   printf("Qual sua idade?\n");
   scanf("%d",&idade);
   
    printf(" oi %s você tem %d anos.",nome,idade);

    return 0;
}