
#include <stdio.h>

int main()
{
    
    float produto, vt ;
     
    printf("Qual o valor do produto desejado ?\n");
    scanf("%f", &produto );
    vt = produto - ( produto * 0.05);
    printf("Esse produto com o desconto sai no valor de:%.2f\n",vt);
    
     
    

    return 0;
}