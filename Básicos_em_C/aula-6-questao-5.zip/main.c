
#include <stdio.h>

int main()
{
    int pdq,coxinha,suco,refrigerante,valor_total;
    
    printf("Quantos pão de queijo você pegou?\n");
    scanf("%d",&pdq);
    printf("Quantas coxinhas você pegou?\n");
    scanf("%d",&coxinha);
    printf("Quantos sucos você pegou?\n");
    scanf("%d",&suco);
    printf("Quantos refrigerantes você pegou?\n");
    scanf("%d",&refrigerante);

 valor_total= pdq*2 +coxinha*4 + suco*5 + refrigerante*6;
 printf("Valor a pagar é %d\n",valor_total);
    return 0;
}
