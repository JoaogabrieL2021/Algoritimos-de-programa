
#include <stdio.h>

int main()
{
    float dinheiro;
    int bombom, valor_total,bb;
    printf("Quanto de dinheiro você tem para comprar os bombons?\n ");
    scanf("%f", &dinheiro);
    valor_total = dinheiro/ 2;
    printf("Você pode comprar %d bombons quantos você vai querer?\n",valor_total);
    scanf("%d",&bb);
    
    
    
    
    
    
    
    return 0;
}
