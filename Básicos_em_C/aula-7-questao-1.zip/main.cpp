
#include <stdio.h>

int main()
{
    int lado_cubo, volume_cubo;
    
    printf("Valor do lado do cubo");
    scanf("%d", &lado_cubo);
    
    volume_cubo = lado_cubo * lado_cubo * lado_cubo;
    
    printf("O volume do cubo é %d" , volume_cubo);
    
    
    
    return 0;
}