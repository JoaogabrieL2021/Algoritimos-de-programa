#include <stdio.h>

int main()
{
float nota1,nota2,nota3,media;
int peso1,peso2,peso3;
printf("Qual sua primeira nota e qual seu peso\n");
scanf("%f %d",&nota1,&peso1);



printf("Qual sua segunda nota e qual seu peso?\n");
scanf("%f %d",&nota2,&peso2);


printf("Qual sua terceira nota e qual seu peso?\n");
scanf("%f %d",&nota3,&peso3);
media = (nota1*peso1 + nota2*peso2 + nota3*peso3) / 5;

printf("A sua média ponderada é %.2f.",media);







    return 0;
}