#include <stdio.h>

int main()
{
    int base, altura;
    float area;
    
    printf("Valor do lado da base do triangulo \n");
    scanf("%d", &base);
    
    printf("Valor da altura do triangulo \n");
    scanf("%d", &altura);
    
    
    area = (float) base * altura / 2;
    
    printf("A base do triangulo %.2f" , area  );
    
    
    
    return 0;
}