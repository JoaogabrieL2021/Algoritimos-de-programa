#include <stdio.h>

int main()
{
    float bytes, velocidade, segundos;
    
    printf("Qual é quantidade de bytes do arquivo? \n");
    scanf("%f", &bytes);
    
    printf("Qual é a velocidades de transmissão em bytes? \n");
    scanf("%f", &velocidade);
    
    segundos = bytes / velocidade;
    
    printf("Serão necessários %2.f segundos", segundos);
    
    return 0;
}