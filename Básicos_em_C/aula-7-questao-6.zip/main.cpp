#include <stdio.h>

int main()
{
    float celsius, fahrenheit;
    
    printf("Qual é a temperatura em graus celsius? \n");
    scanf("%f", &celsius);
    
    fahrenheit = 32 + (float)(212 - 32)/100 * celsius;

    printf("O valor da temperatura é %2.f fahrenheit. \n", fahrenheit);
    return 0;
}