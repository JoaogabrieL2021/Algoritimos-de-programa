#include <stdio.h>

int main()
{
    float raio,volume;
    
    printf("Qual é o raio de uma esfera? \n");
    scanf("%f", &raio);
    volume = (float)4/3 * 3.14 * raio*raio*raio;
    

    
    
    printf("O volume da esfera é: %.2f", volume);
    
    
    
    
    
    
    return 0;
}