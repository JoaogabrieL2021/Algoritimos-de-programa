#include <stdio.h>

int main()
{
  float km,milhas,conversão;
  
  milhas = 0.621371;
  printf("Quantos kilometros você quer converter para milha?\n");
  
  scanf("%f",&km);
  conversão = km * 0.621371;
  printf("%f kilometros são %f milhas",km,conversão);
  
  
  
  
  
    return 0;
}