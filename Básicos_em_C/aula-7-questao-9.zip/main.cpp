#include <stdio.h>

int main()
{
  float raio,altura,volume;
  
  
  printf("Qual a altura do cilindro?\n");
  
  scanf("%f",&altura);
  printf("Qual o raio do cilindro?\n ");
  scanf("%f",&raio);
  volume = 3.14*raio*raio*altura;
  printf("O volume do cilindro a ser preenchido com água é : %.2f ",volume);
  
  
  
  
  
    return 0;
}